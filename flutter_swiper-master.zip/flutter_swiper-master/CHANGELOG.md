
## [1.1.5] - [2019/03/10]

 * Fix findRenderObject is null


## [1.1.4] - [2018/10/18]

## [1.1.2] - [2018/10/10]
    * Fix #7
    * Support layout for pagination.

## [1.1.1] - [2018/09/20]
    * Fix `test` failure.

## [1.1.0] - [2018/09/20]
    * Fix index bug ,See #11
    * Enable `autoplayDisableOnInteraction` property, if set `true`,disable autoplay when user swipes.

## [1.0.7] - [2018/09/02]
    * Don't call SwiperController's dispose when `Swiper` dispose.

## [1.0.6] - [2018/08/28]
    * Implement vertical scroll direction for `TINDER` and `STACK` layout, see #9

## [1.0.5] - [2018/08/09]
    * Add feature : support fade for `viewportFraction`

## [1.0.4] - [2018/07/18]
    * Fix some typo,thanks to [csharad](https://github.com/csharad)

## [1.0.3] - [2018/07/18]
    * Use new to create everything. See #5

## [1.0.2] - [2018/07/16]
    * Fix #4

## [1.0.1] - [2018/07/11]
    * Add layout (CUSTOM) so that you can create your own layout

## [1.0.0] - [2018/07/08]
    * Add layouts ( DEFAULT,STACK,TINDER )
    * Allow to put pagination outer of the swiper container.

## [0.0.9] - [2018/06/10]
    * Add ci
    * Add testcase

## [0.0.8] - [2018/06/07]
    * And chinese document
    * Update infinity_page_view version to 1.0.0

## [0.0.7] - [2018/05/24]
    * The default color of pagination is ThemeData.scaffoldBackgroundColor and ThemeData.primaryColor
    * The default color of control buttons is ThemeData.primaryColor and ThemeData.disabledColor
    * The alignment of pagination is Alignment.bottomCenter by default when scrollDirection== Axis.horizontal, Alignment.centerRight by default when scrollDirection== Axis.vertical
    * Change default value of `autoplay` to false

## [0.0.6] - [2018/05/24]
    * Fix index bug
        
## [0.0.5] - [2018/05/24]
    * Fix zero itemCount bug

## [0.0.4] - [2018/05/20]
    * Update README

## [0.0.3] - [2018/05/20]
    * Update README
    * Support none loop mode
    * Add more examples

## [0.0.2] - [2018/05/20]
    * Autoplay
    * Plugins support 
    * Examples

## [0.0.1] - [2018/05/20]
    * Infinite loop
    * Control buttons
    * Pagination
    * Custom control buttons
    * Custom pagination
    * Controler