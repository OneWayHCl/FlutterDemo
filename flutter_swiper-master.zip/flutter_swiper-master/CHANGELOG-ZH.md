## [1.1.1] - [2018/09/20]
    * 修复自动集成测试错误

## [1.1.0] - [2018/09/20]
    * 修复index的bug ,见 #11
    * 增加 `autoplayDisableOnInteraction` 选项, 如果设置为true，那么在用户滑动的时候停止自动播放，滑动之后重新自动播放


## [1.0.7] - [2018/09/02]
    * 在Swiper dispose的时候不调用Controller的dispose.

## [1.0.6] - [2018/08/28]
    * `TINDER` 和 `STACK` 这两种布局方式实现垂直滚动, #9

## [1.0.5] - [2018/08/09]
    * viewportFraction<1.0增加fade参数

## [1.0.4] - [2018/07/18]
    * 修复一些错别字，感谢[csharad](https://github.com/csharad)
   
## [1.0.3] - [2018/07/18]
    * 根据#5 ,用new来创建对象

## [1.0.2] - [2018/07/16]
    * 修复 #4

## [1.0.1] - [2018/07/11]
    * 支持布局方式(CUSTOM),你可以定制你自己的布局
    
## [1.0.0] - [2018/07/08]
    * 增加布局方式( DEFAULT,STACK,TINDER )
    * 可以将分页指示器放在容器外面

## [0.0.9] - [2018/06/10]
    * 增加CI
    * 增加测试用例

## [0.0.8] - [2018/06/07]
    * 新增中文文档
    * 更新依赖包：infinity_page_view 版本到 1.0.0

## [0.0.7] - [2018/05/24]
    * The default color of pagination is ThemeData.scaffoldBackgroundColor and ThemeData.primaryColor
    * The default color of control buttons is ThemeData.primaryColor and ThemeData.disabledColor
    * The alignment of pagination is Alignment.bottomCenter by default when scrollDirection== Axis.horizontal, Alignment.centerRight by default when scrollDirection== Axis.vertical
    * Change default value of `autoplay` to false

## [0.0.6] - [2018/05/24]
    * Fix index bug

## [0.0.5] - [2018/05/24]
    * Fix zero itemCount bug
    
## [0.0.4] - [2018/05/20]
    * Update README

## [0.0.3] - [2018/05/20]
    * Update README
    * Support none loop mode
    * Add more examples

## [0.0.2] - [2018/05/20]
    * Autoplay
    * Plugins support 
    * Examples

## [0.0.1] - [2018/05/20]
    * Infinite loop
    * Control buttons
    * Pagination
    * Custom control buttons
    * Custom pagination
    * Controler