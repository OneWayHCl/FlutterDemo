class Config {
  static const PAGE_SIZE = 10;
  // static const BASE_URL = "http://172.20.10.3:3000";
  static const BASE_URL = "http://192.168.11.104:3000";
}
