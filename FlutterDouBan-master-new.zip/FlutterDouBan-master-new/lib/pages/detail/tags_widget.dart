import 'package:flutter/material.dart';

class TagsWidget extends StatelessWidget {
  final List<String> tags;

  TagsWidget({Key key, @required this.tags}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return null;
  }
}
