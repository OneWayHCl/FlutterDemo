import 'package:flutter/material.dart';

///院线电影
class MovieListPage extends StatelessWidget {

  MovieListPage({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return null;
  }
}
