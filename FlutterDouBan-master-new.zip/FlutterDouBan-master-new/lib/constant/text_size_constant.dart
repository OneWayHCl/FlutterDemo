class TextSizeConstant {
  ///影院热映、即将上映、豆瓣热门字体大小
  static const BookAudioPartTabBar = 20.0;

}
