class CacheKey {
  static String USE_NET_DATA = 'USE_NET_DATA';
}